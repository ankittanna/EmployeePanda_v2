angular.module('EmployeePanda.controllers')
.controller('SplashCtrl', function($scope) {

});